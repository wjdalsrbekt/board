package com.subject.beans;

public class Subject {
	private String id;
	private String sub0;
    private String sub1;
    private String sub2;
    private String sub3;
    private String sub4;
    private String sub5;
    private String sub6;
    private String sub7;
    private String sub8;
    private String sub9;
    private String sub10;
    private String sub11;
    private String sub12;
    private String sub13;
    private String sub14;
    private String sub15;
    private String sub16;
    private String sub17;
    private String sub18;
    private String sub19;
    private String sub20;
    private String sub21;
    private String sub22;
    private String sub23;
    private String sub24;
    private String sub25;
    private String sub26;
    private String sub27;
    private String sub28;
    private String sub29;
    private String sub30;
    private String sub31;
    private String sub32;
    private String sub33;
    private String sub34;
    private String sub35;
    private String sub36;
    private String sub37;
    private String sub38;
    private String sub39;
    private String sub40;
    private String sub41;
    private String sub42;
    private String sub43;
    private String sub44;
    private String sub45;
    private String sub46;
    private String sub47;
    private String sub48;
    private String sub49;
    private String sub50;
    private String sub51;
    private String sub52;
    private String sub53;
    private String sub54;
    private String sub55;
    private String sub56;
    private String sub57;
    private String sub58;
    private String sub59;
    private String sub60;
    private String sub61;
    private String sub62;
    private String sub63;
    private String sub64;
    private String sub65;
    
    
    public String getId() {
    	return id;
    }
    public String getSub0() {
        return sub0;
}
public void setSub0(String sub0) {
        this.sub0 = sub0;
}
    public String getSub1() {
            return sub1;
    }
    public void setSub1(String sub1) {
            this.sub1 = sub1;
    }
    public String getSub2() {
            return sub2;
    }
    public void setSub2(String sub2) {
            this.sub2 = sub2;
    }
    public String getSub3() {
            return sub3;
    }
    public void setSub3(String sub3) {
            this.sub3 = sub3;
    }
    public String getSub4() {
            return sub4;
    }
    public void setSub4(String sub4) {
            this.sub4 = sub4;
    }
    public String getSub5() {
            return sub5;
    }
    public void setSub5(String sub5) {
            this.sub5 = sub5;
    }
    public String getSub6() {
            return sub6;
    }
    public void setSub6(String sub6) {
            this.sub6 = sub6;
    }
    public String getSub7() {
            return sub7;
    }
    public void setSub7(String sub7) {
            this.sub7 = sub7;
    }
    public String getSub8() {
            return sub8;
    }
    public void setSub8(String sub8) {
            this.sub8 = sub8;
    }
    public String getSub9() {
            return sub9;
    }
    public void setSub9(String sub9) {
            this.sub9 = sub9;
    }
    public String getSub10() {
            return sub10;
    }
    public void setSub10(String sub10) {
            this.sub10 = sub10;
    }
    public String getSub11() {
            return sub11;
    }
    public void setSub11(String sub11) {
            this.sub11 = sub11;
    }
    public String getSub12() {
            return sub12;
    }
    public void setSub12(String sub12) {
            this.sub12 = sub12;
    }
    public String getSub13() {
            return sub13;
    }
    public void setSub13(String sub13) {
            this.sub13 = sub13;
    }
    public String getSub14() {
            return sub14;
    }
    public void setSub14(String sub14) {
            this.sub14 = sub14;
    }
    public String getSub15() {
            return sub15;
    }
    public void setSub15(String sub15) {
            this.sub15 = sub15;
    }
    public String getSub16() {
            return sub16;
    }
    public void setSub16(String sub16) {
            this.sub16 = sub16;
    }
    public String getSub17() {
            return sub17;
    }
    public void setSub17(String sub17) {
            this.sub17 = sub17;
    }
    public String getSub18() {
            return sub18;
    }
    public void setSub18(String sub18) {
            this.sub18 = sub18;
    }
    public String getSub19() {
            return sub19;
    }
    public void setSub19(String sub19) {
            this.sub19 = sub19;
    }
    public String getSub20() {
            return sub20;
    }
    public void setSub20(String sub20) {
            this.sub20 = sub20;
    }
    public String getSub21() {
            return sub21;
    }
    public void setSub21(String sub21) {
            this.sub21 = sub21;
    }
    public String getSub22() {
            return sub22;
    }
    public void setSub22(String sub22) {
            this.sub22 = sub22;
    }
    public String getSub23() {
            return sub23;
    }
    public void setSub23(String sub23) {
            this.sub23 = sub23;
    }
    public String getSub24() {
            return sub24;
    }
    public void setSub24(String sub24) {
            this.sub24 = sub24;
    }
    public String getSub25() {
            return sub25;
    }
    public void setSub25(String sub25) {
            this.sub25 = sub25;
    }
    public String getSub26() {
            return sub26;
    }
    public void setSub26(String sub26) {
            this.sub26 = sub26;
    }
    public String getSub27() {
            return sub27;
    }
    public void setSub27(String sub27) {
            this.sub27 = sub27;
    }
    public String getSub28() {
            return sub28;
    }
    public void setSub28(String sub28) {
            this.sub28 = sub28;
    }
    public String getSub29() {
            return sub29;
    }
    public void setSub29(String sub29) {
            this.sub29 = sub29;
    }
    public String getSub30() {
            return sub30;
    }
    public void setSub30(String sub30) {
            this.sub30 = sub30;
    }
    public String getSub31() {
            return sub31;
    }
    public void setSub31(String sub31) {
            this.sub31 = sub31;
    }
    public String getSub32() {
            return sub32;
    }
    public void setSub32(String sub32) {
            this.sub32 = sub32;
    }
    public String getSub33() {
            return sub33;
    }
    public void setSub33(String sub33) {
            this.sub33 = sub33;
    }
    public String getSub34() {
            return sub34;
    }
    public void setSub34(String sub34) {
            this.sub34 = sub34;
    }
    public String getSub35() {
            return sub35;
    }
    public void setSub35(String sub35) {
            this.sub35 = sub35;
    }
    public String getSub36() {
            return sub36;
    }
    public void setSub36(String sub36) {
            this.sub36 = sub36;
    }
    public String getSub37() {
            return sub37;
    }
    public void setSub37(String sub37) {
            this.sub37 = sub37;
    }
    public String getSub38() {
            return sub38;
    }
    public void setSub38(String sub38) {
            this.sub38 = sub38;
    }
    public String getSub39() {
            return sub39;
    }
    public void setSub39(String sub39) {
            this.sub39 = sub39;
    }
    public String getSub40() {
            return sub40;
    }
    public void setSub40(String sub40) {
            this.sub40 = sub40;
    }
    public String getSub41() {
            return sub41;
    }
    public void setSub41(String sub41) {
            this.sub41 = sub41;
    }
    public String getSub42() {
            return sub42;
    }
    public void setSub42(String sub42) {
            this.sub42 = sub42;
    }
    public String getSub43() {
            return sub43;
    }
    public void setSub43(String sub43) {
            this.sub43 = sub43;
    }
    public String getSub44() {
            return sub44;
    }
    public void setSub44(String sub44) {
            this.sub44 = sub44;
    }
    public String getSub45() {
            return sub45;
    }
    public void setSub45(String sub45) {
            this.sub45 = sub45;
    }
    public String getSub46() {
            return sub46;
    }
    public void setSub46(String sub46) {
            this.sub46 = sub46;
    }
    public String getSub47() {
            return sub47;
    }
    public void setSub47(String sub47) {
            this.sub47 = sub47;
    }
    public String getSub48() {
            return sub48;
    }
    public void setSub48(String sub48) {
            this.sub48 = sub48;
    }
    public String getSub49() {
            return sub49;
    }
    public void setSub49(String sub49) {
            this.sub49 = sub49;
    }
    public String getSub50() {
            return sub50;
    }
    public void setSub50(String sub50) {
            this.sub50 = sub50;
    }
    public String getSub51() {
            return sub51;
    }
    public void setSub51(String sub51) {
            this.sub51 = sub51;
    }
    public String getSub52() {
            return sub52;
    }
    public void setSub52(String sub52) {
            this.sub52 = sub52;
    }
    public String getSub53() {
            return sub53;
    }
    public void setSub53(String sub53) {
            this.sub53 = sub53;
    }
    public String getSub54() {
            return sub54;
    }
    public void setSub54(String sub54) {
            this.sub54 = sub54;
    }
    public String getSub55() {
            return sub55;
    }
    public void setSub55(String sub55) {
            this.sub55 = sub55;
    }
    public String getSub56() {
            return sub56;
    }
    public void setSub56(String sub56) {
            this.sub56 = sub56;
    }
    public String getSub57() {
            return sub57;
    }
    public void setSub57(String sub57) {
            this.sub57 = sub57;
    }
    public String getSub58() {
            return sub58;
    }
    public void setSub58(String sub58) {
            this.sub58 = sub58;
    }
    public String getSub59() {
            return sub59;
    }
    public void setSub59(String sub59) {
            this.sub59 = sub59;
    }
    public String getSub60() {
            return sub60;
    }
    public void setSub60(String sub60) {
            this.sub60 = sub60;
    }
    public String getSub61() {
            return sub61;
    }
    public void setSub61(String sub61) {
            this.sub61 = sub61;
    }
    public String getSub62() {
            return sub62;
    }
    public void setSub62(String sub62) {
            this.sub62 = sub62;
    }
    public String getSub63() {
            return sub63;
    }
    public void setSub63(String sub63) {
            this.sub63 = sub63;
    }
    public String getSub64() {
            return sub64;
    }
    public void setSub64(String sub64) {
            this.sub64 = sub64;
    }
    public String getSub65() {
            return sub65;
    }
    public void setSub65(String sub65) {
            this.sub65 = sub65;
    }
}
