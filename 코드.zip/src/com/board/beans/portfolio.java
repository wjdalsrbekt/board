package com.board.beans;



public class portfolio {
	//��ȣ
	private int num;
	private int commcount;
	
	//����
	private String id;
	private String license_num;
	private String license_grade;
	private String license_date;
	private String license_agency;
	private String in_name;
	private String in_period;
	private String in_grade;
	private String in_activity;
	private String out_name;
	private String out_period;
	private String out_grade;
	private String out_activity;
	private String test_name;
	private String test_date;
	private String test_agency;
	private String test_grade;
	private String test_score;
	private String etc;
	
	//�˻��ɼ�
	public String opt;
	
	//�˻�����
	public String condition;
	
	
	
	public String getOpt() {
		return opt;
	}
	public void setOpt(String opt) {
		this.opt = opt;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getLicense_num() {
		return license_num;
	}
	public void setLicense_num(String license_num) {
		this.license_num=license_num;
	}
	public String getLicense_grade() {
		return license_grade;
	}
	public void setLicense_grade(String license_grade) {
		this.license_grade=license_grade;
	}
	public String getLicense_date() {
		return license_date;
	}
	public void setLicense_date(String license_date) {
		this.license_date=license_date;
	}
	public String getLicense_agency() {
		return license_agency;
	}
	public void setLicense_agency(String license_agency) {
		this.license_agency=license_agency;
	}
	public String getIn_name() {
		return in_name;
	}
	public void setIn_name(String in_name) {
		this.in_name=in_name;
	}
	public String getIn_period() {
		return in_period;
	}
	public void setIn_period(String in_period) {
		this.in_period=in_period;
	}
	public String getIn_grade() {
		return in_grade;
	}
	public void setIn_grade(String in_grade) {
		this.in_grade=in_grade;
	}
	public String getIn_activity() {
		return in_activity;
	}
	public void setIn_activity(String in_activity) {
		this.in_activity=in_activity;
	}
	public String getOut_name() {
		return out_name;
	}
	public void setOut_name(String out_name) {
		this.out_name=out_name;
	}
	public String getOut_period() {
		return out_period;
	}
	public void setOut_period(String out_period) {
		this.out_period=out_period;
	}
	public String getOut_grade() {
		return out_grade;
	}
	public void setOut_grade(String out_grade) {
		this.out_grade=out_grade;
	}
	public String getOut_activity() {
		return out_activity;
	}
	public void setOut_activity(String out_activity) {
		this.out_activity=out_activity;
	}
	public String getTest_name() {
		return test_name;
	}
	public void setTest_name(String test_name) {
		this.test_name=test_name;
	}
	public String getTest_date() {
		return test_date;
	}
	public void setTest_date(String test_date) {
		this.test_date=test_date;
	}
	public String getTest_agency() {
		return test_agency;
	}
	public void setTest_agency(String test_agency) {
		this.test_agency=test_agency;
	}
	public String getTest_grade() {
		return test_grade;
	}
	public void setTest_grade(String test_grade) {
		this.test_grade=test_grade;
	}
	public String getTest_score() {
		return test_score;
	}
	public void setTest_score(String test_score) {
		this.test_score=test_score;
	}
	public String getEtc() {
		return etc;
	}
	public void setEtc(String etc) {
		this.etc=etc;
	}
	
	
}
